## High Sierra Boot Theme


### Preview

![preview.jpg](preview.jpg)

### Install

Download from Release and copy the folder to your EFI theme path.